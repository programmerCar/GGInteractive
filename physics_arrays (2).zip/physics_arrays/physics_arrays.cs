using GameDev.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Diagnostics;
using Box2D.XNA.TestBed.Framework;
using Box2D.XNA;

namespace GameDev
{
    class physics_arrays : Module
    {
        #region Variables
        // Height of the starting, flat platform. Also used to place the coaster
        private float _platformHeight;
        private SpriteBatch _spriteBatch;
        // for instructions
        private SpriteFont _font;
        private PhysicsAPI _physics = new PhysicsAPI();
        // The double array of coasters
        private Body[][] _coaster;
        // Used w/ OldKeyboardState for tracking single presses only
        private KeyboardState _currentKeyboardState;
        private KeyboardState _oldKeyboardState;
        // The height to place the boxes, determined via a ray cast
        private float _targetTrackHeight = 0.0f;
        private List<Body> _boxes = new List<Body>();
        #endregion

        /// <summary>
        /// Initializes the coaster cart. Destroys an old one, if it's still around
        /// </summary>
        private void InitCart()
        {
            #region CleanupCoasterCode
            if (_coaster != null)
            {
                foreach (Body[] bodyList in _coaster)
                {
                    foreach (Body b in bodyList)
                    {
                        if (b != null)
                        {
                            _physics.B2DWorld.DestroyBody(b);
                        }
                    }
                }
            }
            #endregion

            //*********** Begin Focus Area 2 ***********//
            float[] coasterSizes = { 1.75f, 1.5f, 1.25f };
            _coaster = CreateCoaster(coasterSizes);

            //*********** End Focus Area 2 ***********//

        }
        
        /// <summary>
        /// Initializes the boxes, destroys the old ones if they are around
        /// </summary>
        private void InitBoxes()
        {
            #region CleanupBoxesCode
            if (_boxes != null && _boxes.Count > 0)
            {
                foreach (Body b in _boxes)
                {
                    if (b != null)
                    {
                        _physics.B2DWorld.DestroyBody(b);
                    }
                }
            }
            #endregion
            //*********** Begin Focus Area 3 ***********//
            float[][] jaggedArray = new float[4][];
            jaggedArray[0] = new float[] { 7.0f };
            jaggedArray[1] = new float[] { 7.0f, 7.0f };
            jaggedArray[2] = new float[] { 7.0f, 7.0f, 7.0f };
            jaggedArray[3] = new float[] { 7.0f, 7.0f, 7.0f, 7.0f };
            CreateBoxArrays(jaggedArray);
            //*********** End Focus Area 3 ***********//

        }
        
        /// <summary>
        /// Create function. Initialize objects not related to content here
        /// </summary>
        public override void Create()
        {
        }
        
        /// <summary>
        /// Load XNA/MonoGame content here
        /// </summary>
        /// <param name="contentManager">The single instance of ContentManager used in the game</param>
        /// <param name="graphics">The single instance of GraphicsDevice used in the game</param>
        public override void LoadContent()
        {
            base.LoadContent();
            _spriteBatch = new SpriteBatch(_graphicsDevice);
            _font = _contentManager.Load<SpriteFont>("Fonts\\SegoeUIMono");
            // Gravity is set to super high, because that makes it look more like a roller coaster
            _physics.Init(new Vector2(0.0f, -100.0f), true, _graphicsDevice, _contentManager);
            
            //*********** Begin Focus Area 1 ***********//
            float[] coasterTrackHeights = new float[4];
            coasterTrackHeights[0] = 100.0f;
            coasterTrackHeights[1] = -50.0f;
            coasterTrackHeights[2] = 50.0f;
            coasterTrackHeights[3] = -50.0f;
            //*********** End Focus Area 1 ***********//


            CreateTrack(coasterTrackHeights);
            InitCart();

            InitBoxes();
        }
        
        /// <summary>
        /// Update function
        /// </summary>
        /// <param name="time">Provides a snapshot of timing values.</param>
        public override void Update(GameTime time)
        {
            _physics.Step();
            DoInput();
        }
        
        /// <summary>
        /// Main rendering code executed here
        /// </summary>
        public override void Render()
        {
            _physics.Draw(800);
            _spriteBatch.Begin();
            _spriteBatch.DrawString(_font, "Arrow Keys to Apply Impulse. Press \"R\" to reset the coaster.", new Vector2(0.0f, 0.0f), Color.MidnightBlue);
            _spriteBatch.End();
        }
        
        /// <summary>
        /// Creates the roller coaster track
        /// </summary>
        /// <param name="coasterHeights">Array of floats that determines the height of the coaster</param>
        private void CreateTrack(float [] coasterHeights)
        {
            if (coasterHeights == null)
                return;
            // This is the starting point of the track
            float startingXOffset = -600.0f;
            
            float[] periods = 
            {
                0.097f, 0.097f, 0.097f, 0.097f, 0.097f
            };
            // Number of the actual tracks, to achieve a nice curve
            int size = 32;
            // The width of each track node
            float width = 8.0f;
            // The bottom position of the track
            float bottomPosition = -1000.0f;
            // This tracks the position of the current track on the X
            float xOffset = 0.0f;
            // This tracks the
            float nextHeight = 0.0f;
            Color color = Color.Azure;
            _platformHeight = coasterHeights[0] * (float)Math.Sin(periods[0]) * 10.1f;
            Vector2[] startingVerts01 = new Vector2[]
            {
                new Vector2(0.0f, _platformHeight),
                new Vector2(0.0f, bottomPosition),
                new Vector2(128.0f, bottomPosition),
                new Vector2(128.0f, _platformHeight)
            };
            // Create the base
            _physics.CreateStaticQuad(-584.0f, 0.0f, startingVerts01, color, 1.0f);
            // Create the curvey track
            for (int i = 0; i < coasterHeights.Length; i++)
            {
                // Detect which portion of the track is being built
                int j = 1;
                if (i == 0)
                    j =18; // We want to start a little over half of the first track to prevent overlap
                // Place the Static Boxes to create the tracks, using a Sine wave
                for (; j <= size; j++)
                {

                    float currentHeight = coasterHeights[i] * (float)Math.Sin(j * periods[i]);

                    if (j == 18 && i == 0)
                        nextHeight = currentHeight;
                    Vector2[] verts01 = new Vector2[]
                    {
                        new Vector2(0.0f, nextHeight),
                        new Vector2(0.0f, bottomPosition),
                        new Vector2(width, bottomPosition),
                        new Vector2(width, currentHeight)
                    };
                    nextHeight = currentHeight;
                  
                    _physics.CreateStaticQuad(j * width + startingXOffset + xOffset, 0.0f, verts01, color, 1.0f);
                }
                xOffset += size * width;
                color = Color.Azure;
            }
        }
        
        /// <summary>
        /// Creates the actual roller coaster
        /// </summary>
        /// <param name="cartSizes">Array of floats that determines the size of the carts</param>
        /// <returns></returns>
        private Body[][] CreateCoaster(float [] cartSizes)
        {
            // Validating the array passed in. If it's null or less than the size of 4 (number of carts), do nothing but return null
            if (cartSizes == null)
                return null;
            // if any of the sizes passed in are less than or equal to zero, do nothing but return null
            foreach (float f in cartSizes)
            {
                if (f <= 0.0f)
                    return null;
            }
            // Find the largest scale
            var largestScale = cartSizes.Max(x => x);
            // set the starting point of the coaster to the targeted platform + it's own size
            float height = _platformHeight + 11.0f * largestScale;
            // Where the coaster will start spawning from
            float startingX = -450.0f + 15.0f * cartSizes.Length;
            // how much we move the coaster spawn point back in the x
            float increment = 30.0f;
            // Create the array of carts
            Body[][] carts = new Body[cartSizes.Length][];
            int i = 0;
            // Create the array of Bodies
            foreach (float f in cartSizes)
            {
                carts[i] = CreateCart(new Vector2(startingX - (increment * i), height), f);
                i++;
            }
            // Connect the carts, via DistanceJoints
            for (i = 0; i < carts.Length; i++ )
            {
                if (i >= 1)
                {
                    _physics.DistanceJoint(carts[i - 1][0], carts[i][0], new Vector2(-10.0f, 0.0f), new Vector2(10.0f, 0.0f), 0.1f, 28.0f);
                }
            }
            return carts;
        }
        
        /// <summary>
        /// Creates a single cart, for building a roller coaster
        /// </summary>
        /// <param name="position">Where the cart goes</param>
        /// <param name="sizeScale">The modifier to scale</param>
        /// <returns></returns>
        private Body[] CreateCart(Vector2 position, float sizeScale)
        {

            Body[] cart = 
            {
                _physics.CreateBox(position, new Vector2(8.0f, 2.0f) * sizeScale, Color.DarkBlue, 1.0f),
                _physics.CreateBox(new Vector2(position.X + 5.0f * sizeScale,position.Y + 5.0f * sizeScale), new Vector2(3.0f, 6.0f) * sizeScale, Color.DarkBlue, 1.0f),
                _physics.CreateBox(new Vector2(position.X - 10.0f * sizeScale,position.Y + 5.0f * sizeScale), new Vector2(1.0f, 3.0f) * sizeScale, Color.DarkBlue, 1.0f),
                _physics.CreateCircle(new Vector2(position.X + 8.0f  * sizeScale,position.Y - 6.0f * sizeScale), 4.0f  * sizeScale, Color.Navy, 20.0f, 1.0f, 0.2f),
                _physics.CreateCircle(new Vector2(position.X - 8.0f * sizeScale,position.Y - 6.0f * sizeScale), 4.0f  * sizeScale, Color.Navy, 20.0f, 1.0f, 0.2f)
            };

            _physics.WeldJoint(cart[0], cart[1]);
            _physics.WeldJoint(cart[0], cart[2]);
            RevoluteJoint frontjoint = (RevoluteJoint)_physics.RevoluteJoint(cart[0], cart[3], new Vector2(8.0f * sizeScale, -6.0f * sizeScale), new Vector2(0, 0), 0.1f);
            frontjoint.SetMaxMotorTorque(10000.0f);

            RevoluteJoint rearjoint = (RevoluteJoint)_physics.RevoluteJoint(cart[0], cart[4], new Vector2(-8.0f * sizeScale, -6.0f * sizeScale), new Vector2(0, 0), 0.1f);
            rearjoint.SetMaxMotorTorque(10000.0f);
            return cart;
        }
        
        /// <summary>
        /// Process mouse and keyboard input
        /// </summary>
        private void DoInput()
        {
            _currentKeyboardState = Keyboard.GetState();
            float input = _currentKeyboardState.IsKeyDown(Keys.Right) == true ? 1.0f :0.0f;
            if (input <= 0.0f)
            {
                input = _currentKeyboardState.IsKeyDown(Keys.Left) == true ? -1.0f :0.0f;
            }
            // Apply impulse to the carts
            if (_coaster != null && _coaster[0] != null)
            {
                _coaster[0][0].ApplyLinearImpulse(new Vector2(input * 10000.0f, -1.0f),  _coaster[0][0].GetWorldCenter());
            }
            if (_currentKeyboardState.IsKeyDown(Keys.R) && !_oldKeyboardState.IsKeyDown(Keys.R))
            {
                InitCart();
                InitBoxes();
            }
            _oldKeyboardState = _currentKeyboardState;
        }
        
        /// <summary>
        /// Raycast callback to set the Y position of where the boxes that represent the jagged array should go
        /// </summary>
        /// <param name="fixture"></param>
        /// <param name="point"></param>
        /// <param name="normal"></param>
        /// <param name="fraction"></param>
        /// <returns></returns>
        private float RayCastCallbackTest(Fixture fixture, Vector2 point, Vector2 normal, float fraction)
        {
            //Console.WriteLine("Raycast succeeded. Fixture [" + fixture.ToString() + "] Point [" + point.ToString() +"] Normal [" + normal.ToString() + "] fraction [" + fraction.ToString() + "]");
            _targetTrackHeight = point.Y;
            return 0.0f;
        }
        
        /// <summary>
        /// Uses jagged arrays to stack some boxes
        /// </summary>
        /// <param name="jaggedArray">The 2D jaggerarray</param>
        private void CreateBoxArrays(float [][]jaggedArray)
        {
            if (jaggedArray == null)
                return;

            // Offset to start from
            float startingXPos = 300.0f;
            // how much to increment by on the x
            float xIncrement = 0.0f;
            // Position 1 for the ray cast, this is the origin
            Vector2 p1 = new Vector2(300.0f, 300.0f);
            // Position 2 for the ray cast, this is the target
            Vector2 p2 = new Vector2(300.0f, -1000.0f);
            // The whole purpose of this raycast is to caculate where the boxes' heights should be. We dod that by passing
            // in the RayCastCallbackTest function
            _physics.B2DWorld.RayCast(RayCastCallbackTest, p1, p2);
            
            for (int i = 0; i < jaggedArray.Length; i++)
            {
                float[] innerArray = jaggedArray[i];
                if (innerArray != null && innerArray.Length > 0)
                {
                    for (int j = 0; j < innerArray.Length; j++)
                    {
                        _boxes.Add(_physics.CreateBox(new Vector2(startingXPos, _targetTrackHeight + (j + 1) * jaggedArray[i][j] * 2.0f), new Vector2(jaggedArray[i][j], jaggedArray[i][j]), _physics.RandomColor(), 0.2f));
                        xIncrement = jaggedArray[i][j] * 3.0f;
                    }
                    startingXPos += xIncrement;
                }
            }
        }
    }
    
}
